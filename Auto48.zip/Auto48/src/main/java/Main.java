public class Main {
    public static void main(String[] args)
    {
        int result = 1 + 1;
        System.out.println("1 + 1 = " + result);
        System.out.println("Hello world!");
    }

}